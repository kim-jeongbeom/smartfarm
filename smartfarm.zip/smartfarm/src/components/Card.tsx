import React from "react";

const Hero = () => {
return (
<div className="ml-20 w-[500px] h-60 bg-sky-100 shadow p-4 ">ddddd
    <img
        src="/src/assets/logo.png"
        style={{ height: '70px', width: 'auto' }}
    />
    </div>
);